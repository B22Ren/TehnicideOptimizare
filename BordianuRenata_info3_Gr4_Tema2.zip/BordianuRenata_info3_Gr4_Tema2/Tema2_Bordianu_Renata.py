import time
import cv2
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import TruncatedSVD

nr_pers = 20
nr_poze_pers = 8
rezolutie = 112 * 92
caleDB = r'C:\Users\Renata\Desktop\TehniciOptimizare\BordianuRenata_info3_Gr4_Tema2\att_faces'

def mat_Antrenare(caleDB):
    A = np.zeros((rezolutie, nr_pers * nr_poze_pers))
    for i in range(1, nr_pers + 1):
        caleFolder = f"{caleDB}\\s{i}\\"
        for j in range(1, nr_poze_pers + 1):
            calePoza = f"{caleFolder}{j}.pgm"
            poza = cv2.imread(calePoza, 0)
            pozaVectorizata = poza.flatten()
            A[:, (i - 1) * nr_poze_pers + j - 1] = pozaVectorizata
    return A


def Eig_L(A, k):
    medie = np.mean(A, axis=1)
    A = (A.T - medie).T
    L = np.dot(A.T, A)
    d, V = np.linalg.eigh(L)
    idx = np.argsort(d)[-k:]
    V = V[:, idx]
    V = np.dot(A, V)
    return V, medie


def Eig_SVD(A, k):
    medie = np.mean(A, axis=1)
    A = (A.T - medie).T
    svd = TruncatedSVD(n_components=k)
    V = svd.fit_transform(A.T)
    V = svd.components_.T
    return V, medie


def Eig_C(A, k):
    medie = np.mean(A, axis=1)
    A = (A.T - medie).T
    C = np.dot(A, A.T)
    d, V = np.linalg.eigh(C)
    idx = np.argsort(d)[-k:]
    V = V[:, idx]
    return V, medie


def print_poze(eigenfaces, titlu):
    plt.figure(figsize=(10, 8))
    num_faces = min(eigenfaces.shape[1], 20)
    for i in range(num_faces):
        plt.subplot(4, 5, i + 1)
        plt.imshow(eigenfaces[:, i].reshape(112, 92), cmap='gray')
        plt.axis('off')
    plt.suptitle(titlu)
    plt.show()


A = mat_Antrenare(caleDB)
k_values = [20, 40, 60, 80, 100]
timp_exec_L = []
timp_exec_SVD = []
timp_exec_C = []

for k in k_values:
    print(f'\n k = {k}')
    
    start_time = time.time()
    eigenfaces_L, _ = Eig_L(A, k)
    timp_exec_L.append(time.time() - start_time)
    print_poze(eigenfaces_L, f"Eig_L cu k={k}")
    
    start_time = time.time()
    eigenfaces_SVD, _ = Eig_SVD(A, k)
    timp_exec_SVD.append(time.time() - start_time)
    print_poze(eigenfaces_SVD, f"Eig_SVD cu k={k}")
    
    start_time = time.time()
    eigenfaces_C, _ = Eig_C(A, k)
    timp_exec_C.append(time.time() - start_time)
    print_poze(eigenfaces_C, f"Eig_C cu k={k}")


df = pd.DataFrame({
    'k': k_values,
    'Timp L (sec)': timp_exec_L,
    'Timp SVD (sec)': timp_exec_SVD,
    'Timp C (sec)': timp_exec_C
})
print("\nTimpii de execuție:")
print(df)
